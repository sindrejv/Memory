Kodeoppgave - Memory

Med mer til til rådighet er det mye jeg kunne gjort. Først og fremst ville jeg
enten skjult spillbrettet ved oppstart, eller valgt på en annen måte å vise at spillet enda ikke er startet.
Videre ville jeg lagt på opptelling av antall klikk, for å kunne gi brukeren muligheten til å slå
sine egene tidligere rekorder. Dette ville jeg aller helst lagret i en database som Firebase e.l.
Det nest beste ville vært å lagret dette i nettleseren, slik at man ved reload vil kunne se sine tidligere rekorder.



