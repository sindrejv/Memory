const boxList = document.getElementsByClassName("grid-item");
let colorsLeft =  ["blue", "blue", "red", "red", "yellow", "yellow", "black", "black", "green", "green", "pink", "pink"];
let colorsList = [];
let colorCheckArray = [];

function spreadColors() {
    if(colorsLeft.length === 0){
        location.reload();
    }
    //Fisher-Yates Algorithm
    for (let i = colorsLeft.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * i)
        const temp = colorsLeft[i];
        colorsLeft[i] = colorsLeft[j];
        colorsLeft[j] = temp;
    }
    //Create a copy
    colorsList = colorsLeft;
}

document.querySelectorAll('.grid-item').forEach(item => {
    item.addEventListener('click', e => {
        boxList[e.target.id].style.backgroundColor = colorsList[e.target.id];
        colorCheckArray.push(colorsList[e.target.id]);

        //Second click
        if (colorCheckArray.length === 2) {
            //check colors
            if (colorCheckArray[0] === colorCheckArray[1]) {

                //Remove finished colors from colorsLeft
                for (let i = 0; i < colorsLeft.length; i++) {
                    if (colorsLeft[i] === colorCheckArray[0]) {
                        colorsLeft = colorsLeft.filter(e => e !== colorsLeft[i]);
                    }
                }
            }
            //Clear colorCheckArray
            colorCheckArray.splice(0, colorCheckArray.length);

            setTimeout(() => {
                //Turn remaining boxes again
                document.querySelectorAll('.grid-item').forEach(item => {
                    for (let i = 0; i < colorsLeft.length; i++) {
                        if (item.style.backgroundColor === colorsLeft[i]) {
                            item.style.backgroundColor = "white";
                        }
                    }
                })
            }, 500);

            if (colorsLeft.length === 0) {
                alert("You win!");
            }
        }
    })
})
